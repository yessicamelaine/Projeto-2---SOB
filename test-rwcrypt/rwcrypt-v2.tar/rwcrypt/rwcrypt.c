#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/syscalls.h>
#include<linux/file.h>
#include<linux/fs.h>
#include<linux/fcntl.h>

#include <linux/crypto.h>
#include <linux/scatterlist.h>
#include <crypto/hash.h>
#include <crypto/skcipher.h>
#include <crypto/rng.h>


//https://github.com/torvalds/linux/blob/master/fs/read_write.c

/*
asmlinkage long sys_rcrypt(void) {    
	printk("sys_rcrypt\n");
	return 0;
}
asmlinkage long sys_wcrypt(void) {    
	printk("sys_wcrypt\n");
	return 0;
}
*/


// https://elixir.bootlin.com/linux/v4.15.18/source/fs/read_write.c

static inline loff_t file_pos_read(struct file *file)
{
	return file->f_pos;
}

static inline void file_pos_write(struct file *file, loff_t pos)
{
	file->f_pos = pos;
}

static int test_skcipher(char op, char *intext,int intext_size, char *res);
void cleansrt(char *str, int );


SYSCALL_DEFINE3(rcrypt, unsigned int, fd, char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	ssize_t ret = -EBADF;

	if (f.file) {
		loff_t pos = file_pos_read(f.file);
		ret = vfs_read(f.file, buf, count, &pos);
		if (ret >= 0)
			file_pos_write(f.file, pos);
		fdput_pos(f);
	}
	return ret;
}

SYSCALL_DEFINE3(wcrypt, unsigned int, fd, const char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	ssize_t ret = -EBADF;

	if (f.file) {
		loff_t pos = file_pos_read(f.file);
		ret = vfs_write(f.file, buf, count, &pos);
		if (ret >= 0)
			file_pos_write(f.file, pos);
		fdput_pos(f);
	}

	return ret;
}
static int test_skcipher(char op, char *intext,int intext_size, char *res )
{

        struct crypto_skcipher *skcipher=NULL;
        struct skcipher_request *req=NULL;
        struct crypto_skcipher *tfm;
        struct scatterlist src, dst;
        //unsigned int maxdatasize=32;
        unsigned int maxkeysize;
        unsigned int ivsize;
        int ret = -EFAULT;
        char key[]="12345678901234567890123456789012";
        int key_size=32;
        char iv[] ="12345678901234567890123456789012";
        int iv_size=16;
        //char ptext[17]="1234567890123456";
        char ptext[129];
        int ptext_size=129;

        char ctext[129];
        int ctext_size=128;

        DECLARE_CRYPTO_WAIT(wait);
        pr_info("test_skcipher\n");

        cleansrt(ptext,129);
        cleansrt(ctext,129);

        strcpy(ptext,intext);
        pr_info("ptext=%s,intext=%s\n",ptext,intext);
        pr_info("strlen --- ptext=%li,intext=%li\n",strlen(ptext),strlen(intext));

        ptext_size=16;
        ctext_size=16;



        //skcipher  = crypto_alloc_skcipher("cbc(aes)", 0, 0);
        skcipher  = crypto_alloc_skcipher("ecb(aes)", 0, 0);
        if (IS_ERR(skcipher)) {
                pr_info("could not allocate skcipher handle\n");
                return PTR_ERR(skcipher);
        }

        req  = skcipher_request_alloc(skcipher , GFP_KERNEL);
        if (!req) {
                pr_info("could not allocate skcipher request\n");
                ret = -ENOMEM;
                return ret;
                //goto out;
        }
        tfm  = crypto_skcipher_reqtfm(req );
        maxkeysize = tfm->keysize;
        ivsize = crypto_skcipher_ivsize(tfm);
        ret = crypto_skcipher_setkey(tfm , key, key_size);
        //goto out;
        sg_init_one(&src, ptext, ptext_size);
        sg_init_one(&dst, ctext, ctext_size);

        skcipher_request_set_callback(req, 0, crypto_req_done, &wait);
        skcipher_request_set_crypt(req, &src, &dst, iv_size, iv);

        if( op == 'c' ){
                crypto_wait_req(crypto_skcipher_encrypt(req), &wait);
        } else {
                crypto_wait_req(crypto_skcipher_decrypt(req), &wait);
        }
        //crypto_wait_req(crypto_skcipher_encrypt(req), &wait);
        ctext[16]='\0';
        pr_info("ptext=%s,ctext=%s\n",ptext,ctext);
        strcpy(res,ctext);

        skcipher_request_free(req);
        crypto_free_skcipher(skcipher);

        return 0;

}

void cleansrt(char *str, int num){
        int i;
        return;
        for( i=0 ; i < num ; i++ ){
                str[i]='\0';
        }
}


