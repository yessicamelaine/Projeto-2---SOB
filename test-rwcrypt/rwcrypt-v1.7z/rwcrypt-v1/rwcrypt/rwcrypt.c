#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/syscalls.h>
#include<linux/file.h>
#include<linux/fs.h>
#include<linux/fcntl.h>


//https://github.com/torvalds/linux/blob/master/fs/read_write.c

/*
asmlinkage long sys_rcrypt(void) {    
	printk("sys_rcrypt\n");
	return 0;
}
asmlinkage long sys_wcrypt(void) {    
	printk("sys_wcrypt\n");
	return 0;
}
*/


// https://elixir.bootlin.com/linux/v4.15.18/source/fs/read_write.c

static inline loff_t file_pos_read(struct file *file)
{
	return file->f_pos;
}

static inline void file_pos_write(struct file *file, loff_t pos)
{
	file->f_pos = pos;
}


SYSCALL_DEFINE3(rcrypt, unsigned int, fd, char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	ssize_t ret = -EBADF;

	if (f.file) {
		loff_t pos = file_pos_read(f.file);
		ret = vfs_read(f.file, buf, count, &pos);
		if (ret >= 0)
			file_pos_write(f.file, pos);
		fdput_pos(f);
	}
	return ret;
}

SYSCALL_DEFINE3(wcrypt, unsigned int, fd, const char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	ssize_t ret = -EBADF;

	if (f.file) {
		loff_t pos = file_pos_read(f.file);
		ret = vfs_write(f.file, buf, count, &pos);
		if (ret >= 0)
			file_pos_write(f.file, pos);
		fdput_pos(f);
	}

	return ret;
}
