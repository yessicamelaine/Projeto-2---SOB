#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/syscalls.h>
#include "rwcrypt.h"



asmlinkage long sys_rcrypt(void) {    
	printk("sys_rcrypt\n");
	return 0;
}
asmlinkage long sys_wcrypt(void) {    
	printk("sys_wcrypt\n");
	return 0;
}
