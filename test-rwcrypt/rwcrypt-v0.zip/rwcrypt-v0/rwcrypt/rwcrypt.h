asmlinkage long sys_rcrypt(void);
asmlinkage long sys_wcrypt(void);
