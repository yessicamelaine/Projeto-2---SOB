//Sistemas Operacionas B Projeto 2
//Baseado no projeto 1 de Sistemas Operacionas 
//Gabriela Diamante RA 11183399
//Janaina sanches RA 07270085
//Yessica Melaine Castillo RA 13054895


#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>   /* For SYS_xxx definitions */
#include <string.h>
#include <fcntl.h>


#define SYS_rcrypt 334
#define SYS_wcrypt 335

int main(int argc, char *argv[])
{  
         
    long int ret_status;
    int fd;
    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
    int i;
    char msg[10240]="";
    for(i=0;i<512;i++) 
	    strcat(msg,"0123");
	    //strcat(msg,"0");

    int count=strlen(msg);

    fd=open("teste.txt", O_WRONLY | O_TRUNC | O_CREAT, mode );
    ret_status = syscall(SYS_wcrypt,fd,msg,count);
    printf("gravei no arquivo %s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");
    strcpy(msg,"");

    fd=open("teste.txt",O_RDONLY);
    ret_status = syscall(SYS_rcrypt,fd,msg,count);
    printf("li do arquivo %s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");

    return 0;
}
