//Sistemas Operacionas B Projeto 2
//Baseado no projeto 1 de Sistemas Operacionas 
//Gabriela Diamante RA 11183399
//Janaina sanches RA 07270085
//Yessica Melaine Castillo RA 13054895


#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>   /* For SYS_xxx definitions */
#include <string.h>
#include <fcntl.h>


#define SYS_rcrypt 334
#define SYS_wcrypt 335

int main(int argc, char *argv[])
{  
         
    long int ret_status;
    int fd;
    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
    int i;
    char msg[10240]="";
    /*
    for(i=0;i<512;i++) 
	    strcat(msg,"acbdefghij");
	    //strcat(msg,"0");
    */
    strcpy(msg,"\n\nO cálculo de felicidade é um expediente em economia para medir a renda ideal que uma pessoa deve ter para ser feliz. Seu aspecto inovador estaria no fato de considerar que mais dinheiro não necessariamente equivale a mais felicidade. A renda ideal dependeria, em última instância, do lugar onde a pessoa vive e de sua personalidade. É claro que fatores como conforto e segurança entram na conta, mas são relativizados de acordo com o valor que a pessoa dá a eles, o que pode ser influenciado pelo valor que é atribuído a essas coisas no meio em que ela vive.\n\nTomando a já clássica dualidade entre “material” e “espiritual” (que é mais didática do que verdadeira), é certo que, de uma perspectiva espiritual, a felicidade não pode ser circunstancial. Não se trata de acertar alguns pontos na vida, ter um bom emprego, uma boa família, uma boa posição social, saúde e demais coisas do gênero, mas de descobrir o que sobra quando se tira tudo isso.\n\nhttps://www.logon.media/pt-br/felicidade\n\n");
		   
    int count=strlen(msg);

    fd=open("teste.txt", O_WRONLY | O_TRUNC | O_CREAT, mode );
    ret_status = syscall(SYS_wcrypt,fd,msg,count);
    printf("gravei no arquivo %s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");
    strcpy(msg,"");

    fd=open("teste.txt",O_RDONLY);
    ret_status = syscall(SYS_rcrypt,fd,msg,count);
    printf("li do arquivo %s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");

    return 0;
}
