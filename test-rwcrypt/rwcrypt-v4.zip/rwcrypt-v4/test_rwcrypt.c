#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>   /* For SYS_xxx definitions */
#include <string.h>
#include <fcntl.h>


#define SYS_rcrypt 334
#define SYS_wcrypt 335

int main(int argc, char *argv[])
{  
         
    long int ret_status;
    int fd;
    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
    //char msg[256]="Teste";
    //char msg[256]="1234567890123456";
    //char msg[256]="12345678901234567890";
    //char msg[256]="";
    //char *msg;
    //msg=argv[1];
    int i;
    char msg[10240]="";
    for(i=0;i<512;i++) 
	    strcat(msg,".");
	    //strcat(msg,"0");

    int count=strlen(msg);

    fd=open("teste.txt", O_WRONLY | O_TRUNC | O_CREAT, mode );
    ret_status = syscall(SYS_wcrypt,fd,msg,count);
    printf("%s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");
    strcpy(msg,"");

    fd=open("teste.txt",O_RDONLY);
    //ret_status = syscall(SYS_rcrypt,fd,msg,count);
    ret_status = syscall(SYS_rcrypt,fd,msg,count);
    printf("%s=%i out=%li\n",msg,count,ret_status);
    close(fd);
    printf("\n----------\n");

    return 0;
}
