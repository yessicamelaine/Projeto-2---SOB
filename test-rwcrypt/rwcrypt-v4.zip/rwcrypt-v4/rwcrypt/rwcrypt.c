#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/syscalls.h>
#include<linux/file.h>
#include<linux/fs.h>
#include<linux/fcntl.h>

#include <linux/crypto.h>
#include <linux/scatterlist.h>
#include <crypto/hash.h>
#include <crypto/skcipher.h>
#include <crypto/rng.h>



//https://github.com/torvalds/linux/blob/master/fs/read_write.c

/*
asmlinkage long sys_rcrypt(void) {    
	printk("sys_rcrypt\n");
	return 0;
}
asmlinkage long sys_wcrypt(void) {    
	printk("sys_wcrypt\n");
	return 0;
}
*/


// https://elixir.bootlin.com/linux/v4.15.18/source/fs/read_write.c

static inline loff_t file_pos_read(struct file *file)
{
	return file->f_pos;
}

static inline void file_pos_write(struct file *file, loff_t pos)
{
	file->f_pos = pos;
}

static int test_skcipher(char op, char *intext,int intext_size, char *res);
void cleansrt(char *str, int );


SYSCALL_DEFINE3(rcrypt, unsigned int, fd, char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	static loff_t pos;
	ssize_t ret = -EBADF;
	ssize_t ponto=0;
	char *res;
	int ignora=0;
	char op='d';


	mm_segment_t old_fs;
	old_fs = get_fs();
	set_fs(KERNEL_DS);
	pr_info("rcrypt\n");

	res=kmalloc(17,GFP_KERNEL);
	if(count==-1) ignora=1;

	if (f.file) {
	//loop para trabalhar com dados maiores que 16posições
		do {
		cleansrt(res,17);
		pos = file_pos_read(f.file);
		ret = vfs_read(f.file, res, 16, &pos);
		//ret = vfs_read(f.file,  res, 64, &pos);
		if (ret >= 0)
			file_pos_write(f.file, pos);
		fdput_pos(f);

		test_skcipher(op, res,16, &buf[ponto]);

		ponto+=16;
		cleansrt(res,17);
		} while ( ret > 0 && ponto < count  );
		//} while ( ret > 0 && ( ponto < count || ignora ) );
	}

	kfree(res);
	set_fs(old_fs);
	return ret;
}

SYSCALL_DEFINE3(wcrypt, unsigned int, fd, char __user *, buf, size_t, count)
{
	struct fd f = fdget_pos(fd);
	ssize_t ret = -EBADF;
	ssize_t ponto=0;
	char *res;
	char op='c';
	loff_t pos=0;


	mm_segment_t old_fs;
	old_fs = get_fs();
	set_fs(KERNEL_DS);
	pr_info("wcrypt\n");

	res=kmalloc(17,GFP_KERNEL);
	cleansrt(res,17);

	if (f.file) {
		//loop para trabalhar com dados maiores que 16posições
		do {
			test_skcipher(op, &buf[ponto],strnlen(&buf[ponto],16), res);

			pos = file_pos_read(f.file);
			//ret = vfs_write(f.file, buf, count, &pos);
			ret = vfs_write(f.file, (__force const char __user *) res, 16, &pos);
			if (ret >= 0)
				file_pos_write(f.file, pos);
			fdput_pos(f);
			ponto+=16;
			cleansrt(res,17);
		} while ( ponto < count );
	}

	kfree(res);
	set_fs(old_fs);
	return ret;
}

static int test_skcipher(char op, char *intext,int intext_size, char *res )
{

        struct crypto_skcipher *skcipher=NULL;
        struct skcipher_request *req=NULL;
        struct crypto_skcipher *tfm;
        struct scatterlist src, dst;
        //unsigned int maxdatasize=32;
        unsigned int maxkeysize;
        unsigned int ivsize;
        int ret = -EFAULT;
        char key[]="1234567890123456";
        int key_size=16;
        char iv[] ="1234567890123456";
        int iv_size=16;
        //char ptext[17]="1234567890123456";
        char ptext[17];
        int ptext_size=16;

        char ctext[17];
        int ctext_size=16;

        DECLARE_CRYPTO_WAIT(wait);
	pr_info("test_skcipher\n");

	cleansrt(ptext,17);
	cleansrt(ctext,17);

	strncpy(ptext,intext,16);
	ptext[16]='\0';


	ptext_size=16;
	ctext_size=16;



        //skcipher  = crypto_alloc_skcipher("cbc(aes)", 0, 0);
        skcipher  = crypto_alloc_skcipher("ecb(aes)", 0, 0);
        if (IS_ERR(skcipher)) {
                pr_info("could not allocate skcipher handle\n");
                return PTR_ERR(skcipher);
        }

        req  = skcipher_request_alloc(skcipher , GFP_KERNEL);
        if (!req) {
                pr_info("could not allocate skcipher request\n");
                ret = -ENOMEM;
		return ret;
                //goto out;
        }
        tfm  = crypto_skcipher_reqtfm(req );
        maxkeysize = tfm->keysize;
        ivsize = crypto_skcipher_ivsize(tfm);
        ret = crypto_skcipher_setkey(tfm , key, key_size);
        //goto out;
        sg_init_one(&src, ptext, ptext_size);
        sg_init_one(&dst, ctext, ctext_size);

        skcipher_request_set_callback(req, 0, crypto_req_done, &wait);
        skcipher_request_set_crypt(req, &src, &dst, iv_size, iv);

      	if( op == 'c' ){
                crypto_wait_req(crypto_skcipher_encrypt(req), &wait);
        } else {
                crypto_wait_req(crypto_skcipher_decrypt(req), &wait);
        }
	//crypto_wait_req(crypto_skcipher_encrypt(req), &wait);
	ctext[16]='\0';
	pr_info("\n---\nptext=%s,ctext=%s\n---\n",ptext,ctext);
	strncpy(res,ctext,16);
	res[16]='\0';

        skcipher_request_free(req);
        crypto_free_skcipher(skcipher);

        return 0;

}

void cleansrt(char *str, int num){
	int i;
        return;
        for( i=0 ; i < num ; i++ ){
		str[i]='\0';
	}
}

